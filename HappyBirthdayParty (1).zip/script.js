
const startBtn = document.getElementById('startBtn');
const song = document.getElementById('song');
const scene = document.querySelector('.scene');
const flame = document.getElementById('flame');
const banner = document.querySelector('.banner');
const lights = document.querySelector('.lights');
const confettiCanvas = document.getElementById('confetti-canvas');
const balloons = document.querySelector('.balloons');

startBtn.addEventListener('click', () => {
  song.play();
  startBtn.classList.add('hidden');
  scene.classList.remove('hidden');
  listenForBlow();
});

function showCelebration() {
  confettiCanvas.classList.remove('hidden');
  balloons.classList.remove('hidden');
  lights.classList.remove('hidden');
  banner.classList.remove('hidden');
}

async function listenForBlow() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioCtx.createMediaStreamSource(stream);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 256;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    source.connect(analyser);

    let blowFrames = 0;
    const blowThreshold = 50;
    const requiredFrames = 6;

    function detect() {
      analyser.getByteFrequencyData(dataArray);
      const volume = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;

      if (volume > blowThreshold) {
        blowFrames++;
      } else {
        blowFrames = Math.max(0, blowFrames - 1);
      }

      if (blowFrames > requiredFrames && flame.style.opacity !== '0') {
        flame.style.animation = 'fadeOut 1s ease forwards';
        showCelebration();
      } else {
        requestAnimationFrame(detect);
      }
    }

    detect();
  } catch (err) {
    alert('Mic access needed to blow the candle!');
    console.error(err);
  }
}
